package one.digitalinnovation.gof.strategy;

public interface Comportamento {
	void mover();
}
